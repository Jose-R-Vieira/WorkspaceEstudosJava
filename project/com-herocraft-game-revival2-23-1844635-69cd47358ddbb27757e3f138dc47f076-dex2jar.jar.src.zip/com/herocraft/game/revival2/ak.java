package com.herocraft.game.revival2;

import java.lang.reflect.Array;
import java.util.Hashtable;
import java.util.Vector;

final class ak
{
  public static final int[] A = new int[8];
  static int[][] B;
  static int[][] C;
  static int D;
  static int E;
  private static int F;
  private static int G;
  private static short H;
  private static byte I;
  private static byte J;
  private static x K;
  private static Vector L;
  private static boolean M;
  private static int N;
  private static int O;
  private static int P;
  private static int Q;
  private static byte R;
  private static int S;
  private static int T;
  private static int U;
  static int a = 176;
  static int b = 208;
  static int c = 88;
  static int d = 104;
  static b e;
  static Vector f;
  public static boolean g;
  static int h;
  static int i;
  static int j;
  static int k;
  static int l;
  static int m;
  static int n;
  static short[] o;
  static int p;
  public static int q;
  public static int r;
  public static final byte[] s;
  public static final String[] t;
  public static final byte[][] u;
  public static final byte[] v;
  public static final byte[] w;
  public static final short[] x;
  public static final byte[][] y;
  public static final byte[][] z;
  
  static
  {
    F = 1;
    G = 1;
    f = new Vector();
    L = new Vector();
    N = -1;
    O = -1;
    P = -1;
    Q = -1;
    q = 0;
    r = 0;
    s = new byte[] { 19, 18, 17, 17, 17 };
    t = new String[] { "$", "~", "{", "}", "[", "]", ";" };
    byte[] arrayOfByte1 = { 2, 1, 0, 8, 0, 5, 7, 4, 4, 1, 9, 37, 0 };
    byte[] arrayOfByte2 = { 3, 2, 0, 16, 0, 10, 12, 8, 5, 3, 9, 26, 1 };
    byte[] arrayOfByte3 = { 4, 3, 1, 28, 0, 12, 20, 13, 6, 6, 9, 20, 2 };
    byte[] arrayOfByte4 = { 5, 3, 2, 45, 0, 14, 32, 19, 7, 8, 9, 10, 3 };
    byte[] arrayOfByte5 = { 20, 6, 4, 24, 1, 10, 20, 3, 13, 3, 1, 27, 1 };
    byte[] arrayOfByte6 = { 4, 10, 8, 20, 4, 10, 10, 3, 13, 2, 1, 26, 1 };
    byte[] arrayOfByte7 = { 6, 11, 9, 30, 4, 12, 25, 3, 14, 4, 1, 16, 2 };
    byte[] arrayOfByte8 = { 2, 13, 12, 5, 3, 5, 5, 3, 12, 1, 1, 40, 0 };
    byte[] arrayOfByte9 = { 4, 14, 12, 20, 3, 10, 20, 6, 8, 3, 1, 29, 1 };
    byte[] arrayOfByte10 = { 6, 15, 13, 35, 3, 12, 30, 10, 9, 6, 1, 19, 2 };
    byte[] arrayOfByte11 = { 8, 15, 14, 55, 3, 14, 40, 15, 10, 8, 1, 9, 3 };
    byte[] arrayOfByte12 = { 8, 17, 16, 8, 2, 5, 4, 3, 12, 1, 1, 38, 0 };
    byte[] arrayOfByte13 = { 18, 18, 16, 22, 2, 10, 18, 3, 13, 3, 1, 27, 1 };
    byte[] arrayOfByte14 = { 45, 19, 18, 68, 2, 14, 45, 3, 15, 9, 1, 7, 3 };
    byte[] arrayOfByte15 = { 4, 20, 20, 30, 0, 6, 20, 6, 8, 2, 1, 37, 0 };
    byte[] arrayOfByte16 = { 10, 22, 21, 15, 5, 10, 10, 6, 8, 3, 1, 26, 1 };
    byte[] arrayOfByte17 = { 20, 23, 21, 30, 5, 12, 20, 12, 21, 6, 1, 16, 2 };
    byte[] arrayOfByte18 = { 30, 23, 22, 45, 5, 14, 30, 17, 22, 9, 1, 5, 3 };
    byte[] arrayOfByte19 = { 0, 24, 24, 120, -1, 50, 120, 18, 3, 5, 1, 60, 3 };
    byte[] arrayOfByte20 = { 0, 25, 25, 0, -1, 0, 0, 16, 15, 0, 0, 70, 3 };
    u = new byte[][] { arrayOfByte1, arrayOfByte2, arrayOfByte3, arrayOfByte4, { 10, 5, 4, 12, 1, 5, 10, 3, 12, 1, 1, 38, 0 }, arrayOfByte5, { 30, 7, 5, 42, 1, 12, 30, 3, 14, 6, 1, 17, 2 }, { 40, 7, 6, 60, 1, 14, 40, 3, 15, 9, 1, 7, 3 }, { 2, 9, 8, 10, 4, 5, 5, 3, 12, 1, 1, 36, 0 }, arrayOfByte6, arrayOfByte7, { 8, 11, 10, 40, 4, 14, 35, 3, 15, 7, 1, 5, 3 }, arrayOfByte8, arrayOfByte9, arrayOfByte10, arrayOfByte11, arrayOfByte12, arrayOfByte13, { 32, 19, 17, 42, 2, 12, 32, 3, 14, 6, 1, 17, 2 }, arrayOfByte14, arrayOfByte15, arrayOfByte16, arrayOfByte17, arrayOfByte18, arrayOfByte19, arrayOfByte20 };
    v = new byte[af.v.length];
    w = new byte[u.length];
    x = new short[8];
    y = (byte[][])Array.newInstance(Byte.TYPE, new int[] { 8, 2 });
    z = (byte[][])Array.newInstance(Byte.TYPE, new int[] { 8, 2 });
  }
  
  static void a()
  {
    if ((S > 0) && (T > S) && (b.bl == 2L))
    {
      b.bl = 2L;
      b.aN = 1;
      S += 1;
    }
    if ((T > 0) && (b.bl == 4L) && (o != null) && (S == 0))
    {
      b.bl = 2L;
      b.aN = 1;
      S += 1;
    }
  }
  
  static void a(byte paramByte1, byte paramByte2, int paramInt1, int paramInt2, short paramShort, byte paramByte3)
  {
    String str = "";
    if (paramInt1 > 0) {
      str = "" + "_ " + String.valueOf(paramInt1) + ' ' + j.b((short)277);
    }
    if (paramInt2 > 0) {
      str = str + "_ " + String.valueOf(paramInt2) + ' ' + j.b((short)278);
    }
    for (;;)
    {
      paramInt1 = af.y[paramByte3][16];
      b.a((byte)0, new byte[] { paramByte1, paramByte2 }, (short)245, new Object[] { str }, new short[] { 121 }, paramShort, paramInt1);
      return;
    }
  }
  
  static void a(int paramInt)
  {
    b.h(paramInt);
    if (b.ba < 8)
    {
      i1 = n;
      n = B[n][(b.ba + 2)];
      l = B[n][0];
      m = B[n][1];
      if (n == 12)
      {
        if (i1 != 12) {
          break label271;
        }
        if (b.ba != 2) {
          break label213;
        }
        E += af.A[0][b.ba];
        l = B[n][0] + E * D;
        if (E > f.size() - 1)
        {
          n = 13;
          l = B[n][0];
          m = B[n][1];
        }
      }
    }
    label157:
    switch (paramInt)
    {
    }
    label213:
    label263:
    label271:
    Object localObject;
    label546:
    short[] arrayOfShort2;
    byte b1;
    short[] arrayOfShort1;
    label612:
    do
    {
      do
      {
        do
        {
          return;
          if (b.ba != 6) {
            break label157;
          }
          E += af.A[0][b.ba];
          l = B[n][0] + E * D;
          if (E >= 0) {
            break label157;
          }
          n = 10;
          break;
          if (B[i1][0] > B[n][0] + f.size() * D) {}
          for (E = f.size() - 1;; E = 0)
          {
            l = B[n][0] + E * D;
            if (f.size() != 0) {
              break label157;
            }
            if (b.ba != 2) {
              break label263;
            }
            n = 13;
            break;
          }
        } while (K.l != al.G);
        al.b(false);
      } while (al.aI == K.a);
      E = 0;
      a(false);
      return;
      b.q();
      return;
      if (!al.f(al.G)) {}
      for (boolean bool = true;; bool = false)
      {
        al.E = bool;
        e.t();
        return;
      }
      if (p < 20)
      {
        p = 21;
        return;
      }
      p = -20;
      U = 0;
      return;
      localObject = new short[20];
      I = -1;
      switch (n)
      {
      case 9: 
      case 11: 
      default: 
        paramInt = 0;
        arrayOfShort2 = new short[paramInt];
        System.arraycopy(localObject, 0, arrayOfShort2, 0, paramInt);
        if ((I == -1) || ((F == 1) && (G == 1))) {
          break label1467;
        }
        b1 = I;
        arrayOfShort1 = j.a((short)(I + 133));
        localObject = new byte[] { 1, b1 };
      }
    } while (arrayOfShort2.length <= 0);
    paramInt = af.y[K.l][16];
    b.a((byte)6, (byte[])localObject, arrayOfShort2, arrayOfShort1, new short[] { 121, 122 }, paramInt);
    return;
    F = af.A[0][n] + 1;
    G = af.A[1][n] + 1;
    I = K.h[F][G];
    if (I > -1)
    {
      if ((!j.a(w[u[I][1]], K.l)) || (u[I][1] == I) || ((K.q == F) && (K.r == G))) {
        break label1514;
      }
      localObject[0] = 328;
    }
    label1150:
    label1467:
    label1509:
    label1514:
    for (int i1 = 1;; i1 = 0)
    {
      paramInt = i1;
      if (u[I][4] == 3) {
        if ((I == 12) && (K.q == F) && (K.r == G))
        {
          paramInt = i1;
          if (K.p > 0) {}
        }
        else
        {
          paramInt = (byte)(i1 + 1);
          localObject[i1] = 327;
        }
      }
      i1 = paramInt;
      if (K.q == F)
      {
        i1 = paramInt;
        if (K.r == G)
        {
          i1 = paramInt;
          if (K.p != 0)
          {
            i1 = paramInt;
            if (K.h[F][G] != 24)
            {
              i1 = (byte)(paramInt + 1);
              localObject[paramInt] = 333;
            }
          }
        }
      }
      paramInt = i1;
      if (u[I][4] == 1) {
        if ((I == 4) && (K.q == F) && (K.r == G))
        {
          paramInt = i1;
          if (K.p > 0) {}
        }
        else
        {
          int i2 = (byte)(i1 + 1);
          localObject[i1] = 336;
          paramInt = (byte)(i2 + 1);
          localObject[i2] = 335;
        }
      }
      i1 = paramInt;
      if (K.p < 0)
      {
        i1 = paramInt;
        if (K.q == F)
        {
          i1 = paramInt;
          if (K.r == G)
          {
            i1 = (byte)(paramInt + 1);
            localObject[paramInt] = 326;
          }
        }
      }
      paramInt = (byte)(i1 + 1);
      localObject[i1] = 325;
      break label546;
      localObject[0] = 329;
      paramInt = 1;
      break label546;
      F = af.A[0][n] + 1;
      G = af.A[1][n] + 1;
      I = K.h[F][G];
      if (K.m == -1)
      {
        localObject[0] = 330;
        paramInt = 1;
      }
      for (;;)
      {
        if (I >= 21)
        {
          i1 = paramInt;
          if (j.a(w[u[I][1]], K.l))
          {
            i1 = paramInt;
            if (u[I][1] != I) {
              if (K.q == F)
              {
                i1 = paramInt;
                if (K.r == G) {}
              }
              else
              {
                i1 = (byte)(paramInt + 1);
                localObject[paramInt] = 328;
              }
            }
          }
          paramInt = i1;
          if (K.p < 0)
          {
            paramInt = (byte)(i1 + 1);
            localObject[i1] = 326;
          }
          i1 = (byte)(paramInt + 1);
          localObject[paramInt] = 325;
        }
        for (;;)
        {
          paramInt = (byte)(i1 + 1);
          localObject[i1] = 334;
          break;
          if (K.o == 0) {
            break label1509;
          }
          localObject[0] = 332;
          localObject[1] = 331;
          paramInt = 2;
          break label1150;
          i1 = paramInt;
          if (j.a(w[21], K.l))
          {
            i1 = (byte)(paramInt + 1);
            localObject[paramInt] = 329;
          }
        }
        if (f.size() <= 0) {
          break;
        }
        H = al.a(((Short)f.elementAt(E)).shortValue()).b;
        d();
        return;
        b1 = K.l;
        a(new short[] { 121, 122 }, b1);
        return;
        if (K.m == -1)
        {
          localObject[0] = 330;
          paramInt = 1;
          break label546;
        }
        if (K.o == 0) {
          break;
        }
        localObject[0] = 332;
        localObject[1] = 331;
        paramInt = 2;
        break label546;
        if ((F == 1) && (G == 1))
        {
          arrayOfShort1 = K.e;
          localObject = null;
          break label612;
        }
        arrayOfShort1 = j.a((short)159);
        localObject = null;
        break label612;
        paramInt = 0;
      }
    }
  }
  
  static void a(ac paramac)
  {
    if (g)
    {
      d(j.f);
      g = false;
    }
    paramac.a(0, 0, a, b);
    paramac.a(j.e, 0, 0, 0);
    if (U > -al.f)
    {
      u localu = al.Z;
      int i1 = U;
      al.a(paramac, localu, j.z[15][2] + i1, b - al.g - j.z[14][3], al.f, al.g);
      if (U >= 0) {
        al.a(paramac, 2, 2, al.f, al.g, al.b());
      }
    }
    c(paramac);
    b(paramac);
    a(paramac, j.j[af.y[K.l][16]][0]);
    j.a(paramac, 21, 0, h - 5, i + 5);
  }
  
  static void a(ac paramac, int paramInt)
  {
    if ((b.bl <= 1L) || (b.bl >= 5L) || (o == null) || (l != h) || (m != i)) {
      return;
    }
    int i1 = Math.min(o.length * j.t + 4, c + (c >> 1));
    int i2 = Math.max(0, Math.min(h, a - i1));
    int i3 = Math.max(i - j.u - 4 - 16, 0);
    j.a(paramac, i2, i3, i1, j.u + 4, false, paramInt, 0, 0);
    if (b.ar == true) {
      j.r = true;
    }
    if (b.av == true)
    {
      j.b(paramac, o, i2 + 2 - S, i3 + 2, i2 + 2, 0, i1 - 4, b);
      return;
    }
    j.b(paramac, o, i2 + 2 - S, i3 + 2, i2 + 2, i3 + 2, i1 - 4, j.u);
  }
  
  static void a(ac paramac, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean)
  {
    j.a(paramac, paramInt1, paramInt2, paramInt3, 4, paramBoolean, j.j[paramInt5][0], paramInt5);
    paramac.a(255);
    paramac.c(paramInt1 + 1, paramInt2 + 1, (paramInt3 - 2) * paramInt4 / 100, 2);
  }
  
  private static void a(ac paramac, int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int i4 = j.u + 3;
    int i2 = 0;
    if (i2 < paramArrayOfInt.length)
    {
      j.a(paramac, paramInt1, paramInt2 + i2 * i4, j.t + 4, j.u + 4, false, 0, af.y[K.l][16]);
      int i3 = j.t;
      int i5 = j.t;
      int i6 = j.u;
      int i1;
      if (K.j[paramArrayOfInt[i2]] >= 0)
      {
        i1 = -1;
        label86:
        j.a(paramac, i3 + paramInt1 + 4, paramInt2 + i2 * i4, (i5 << 2) + 4, i6 + 4, false, i1, af.y[K.l][16]);
        j.a(paramac, t[paramArrayOfInt[i2]], paramInt1 + 2, i2 * i4 + paramInt2 + 2);
        i3 = 0;
        i1 = i3;
        switch (paramArrayOfInt[i2])
        {
        default: 
          i1 = i3;
        }
      }
      for (;;)
      {
        B[i1][0] = ((j.t >> 1) + paramInt1 + 2);
        B[i1][1] = (i2 * i4 + paramInt2 + (i4 >> 1));
        C[i1] = { paramInt1 + 2, i2 * i4 + paramInt2, j.t * 5 + 5, i4 + 5 };
        if (paramArrayOfInt[i2] != 5) {
          break label457;
        }
        j.a(paramac, '+' + String.valueOf(K.j[paramArrayOfInt[i2]]) + '%', j.t + paramInt1 + 6, i2 * i4 + paramInt2 + 2);
        if (b.aq == true)
        {
          if ((i1 == 15) || (i1 == 9))
          {
            localObject = C[i1];
            localObject[1] -= 20;
          }
          localObject = C[i1];
          localObject[3] += 20;
        }
        i2 += 1;
        break;
        i1 = 16711680;
        break label86;
        i1 = 15;
        continue;
        i1 = 16;
        continue;
        i1 = 9;
        continue;
        i1 = 14;
      }
      label457:
      StringBuilder localStringBuilder = new StringBuilder();
      if (K.j[paramArrayOfInt[i2]] >= 0) {}
      for (Object localObject = "+";; localObject = "")
      {
        j.a(paramac, (String)localObject + String.valueOf(K.j[paramArrayOfInt[i2]]), j.t + paramInt1 + 6, i2 * i4 + paramInt2 + 2);
        break;
      }
    }
    j.a(paramac, paramInt1, paramInt2, j.t + 3 + 4 + (j.t << 2), i4 * paramArrayOfInt.length, af.y[K.l][16], -2, true);
  }
  
  static void a(aq paramaq)
  {
    int i3 = Math.max(af.v[paramaq.e][1], af.v[paramaq.e][2]) << 1;
    int i2 = i3;
    if (i3 == 0) {
      i2 = 1;
    }
    i3 = af.v[paramaq.e][4] * 10;
    int i4 = af.v[paramaq.e][5] * 10;
    if (paramaq.q == 0)
    {
      i2 = i4 >> 1;
      i3 >>= 1;
    }
    for (;;)
    {
      int i1 = paramaq.e;
      Integer localInteger1 = new Integer(i3);
      Integer localInteger2 = new Integer(i2);
      i2 = af.y[paramaq.a][16];
      b.a((byte)12, new byte[] { 2, i1 }, (short)269, new Object[] { localInteger1, localInteger2 }, new short[] { 123, 132 }, (short)187, i2);
      return;
      i3 = i3 * Math.min(paramaq.q, i2) / i2;
      i2 = i4 * Math.min(paramaq.q, i2) / i2;
    }
  }
  
  public static void a(boolean paramBoolean)
  {
    b.C();
    b.a(7, -1, 80);
    K = al.b(al.aI);
    al.d(K.b, K.c);
    F = 1;
    G = 1;
    if (b.aD[b.aJ] == 0)
    {
      b.aD[b.aJ] = true;
      al.a(al.aa, 2, 2, al.f, al.g);
      if (b.aq == true) {
        al.a(al.ar, al.ao, al.ap, al.am, al.an);
      }
      b.aD[b.aJ] = false;
    }
    p = 0;
    U = 0;
    if (b.aq == true)
    {
      q = 0;
      i1 = Math.min(b.bi, b.bj) / 10;
      i2 = j.z[14][3];
      r = b - (i1 + i2);
    }
    int i1 = c;
    int i2 = d;
    int i3 = al.q;
    int i4 = c;
    int i5 = al.p;
    int i6 = d;
    int i7 = al.q;
    int i8 = c;
    int i9 = al.p;
    int i10 = d;
    int i11 = c;
    int i12 = al.p;
    int i13 = d;
    int i14 = al.q;
    int i15 = c;
    int i16 = d;
    int i17 = al.q;
    int i18 = c;
    int i19 = al.p;
    int i20 = d;
    int i21 = al.q;
    int i22 = c;
    int i23 = al.p;
    int i24 = d;
    int i25 = c;
    int i26 = al.p;
    int i27 = d;
    int i28 = al.q;
    int i29 = c;
    int i30 = d;
    int i31 = c;
    int i32 = d;
    int i33 = c;
    int i34 = d;
    int i35 = c;
    int i36 = d;
    int i37 = c;
    int i38 = d;
    int i39 = c;
    int i40 = d;
    int i41 = c;
    int i42 = d;
    int i43 = c;
    int i44 = d;
    int i45 = c;
    int i46 = d;
    B = new int[][] { { i1, i2 - i3, 11, 16, 0, 1, 8, 7, 0, 14, 531 }, { i4 + (i5 >> 1), i6 - (i7 >> 1), 16, 16, 1, 2, 3, 8, 7, 0, 531 }, { i8 + i9, i10, 16, 16, 2, 13, 13, 3, 8, 1, 531 }, { i11 + (i12 >> 1), i13 + (i14 >> 1), 1, 2, 3, 13, 13, 4, 5, 8, 531 }, { i15, i16 + i17, 8, 3, 4, 13, 12, 10, 4, 5, 531 }, { i18 - (i19 >> 1), i20 + (i21 >> 1), 7, 8, 3, 4, 10, 10, 5, 6, 531 }, { i22 - i23, i24, 14, 7, 8, 5, 10, 10, 6, 14, 531 }, { i25 - (i26 >> 1), i27 - (i28 >> 1), 14, 0, 1, 8, 5, 6, 7, 14, 531 }, { i29, i30, 0, 1, 2, 3, 4, 5, 6, 7, 529 }, { i31, i32, 9, 11, 11, 0, 14, 9, 9, 9, 538 }, { i33, i34, 4, 4, 12, 10, 10, 10, 10, 10, 535 }, { i35, i36, 11, 11, 15, 11, 0, 11, 9, 11, 530 }, { i37, i38, 4, 12, 12, 12, 12, 12, 12, 12, 535 }, { i39, i40, 3, 13, 13, 13, 13, 13, 12, 4, 534 }, { i41, i42, 9, 11, 11, 0, 7, 14, 14, 14, 539 }, { i43, i44, 15, 15, 15, 15, 16, 0, 11, 11, 536 }, { i45, i46, 15, 16, 16, 16, 1, 0, 11, 11, 537 } };
    i1 = al.p >> 1;
    i2 = al.q >> 1;
    int[] arrayOfInt1 = { c - i1, d - al.q - i2, al.p, al.q };
    int[] arrayOfInt2 = { c, d - al.q, al.p, al.q };
    int[] arrayOfInt3 = { c + i1, d - i2, al.p, al.q };
    int[] arrayOfInt4 = { c, d, al.p, al.q };
    i3 = c;
    i4 = d;
    i5 = al.p;
    i6 = al.q;
    int[] arrayOfInt5 = { c - al.p, d, al.p, al.q };
    int[] arrayOfInt6 = { c - al.p - i1, d - i2, al.p, al.q };
    i7 = c;
    i8 = al.p;
    i9 = d;
    i10 = al.q;
    i11 = al.p;
    i12 = al.q;
    i13 = c;
    i14 = d;
    i15 = al.p;
    i16 = al.q;
    int[] arrayOfInt7 = { 0, 0, 0, 0 };
    int[] arrayOfInt8 = { 0, 0, 0, 0 };
    C = new int[][] { arrayOfInt1, arrayOfInt2, arrayOfInt3, arrayOfInt4, { i3 - i1, i4 + i2, i5, i6 }, arrayOfInt5, arrayOfInt6, { i7 - i8, i9 - i10, i11, i12 }, { i13 - i1, i14 - i2, i15, i16 }, { 0, 0, 0, 0 }, arrayOfInt7, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, arrayOfInt8, { 0, 0, 0, 0 } };
    af.a(K);
    n = 8;
    i1 = B[n][0];
    j = i1;
    l = i1;
    i1 = B[n][1];
    k = i1;
    m = i1;
    h += 1;
    i += 1;
    g = true;
    M = paramBoolean;
  }
  
  static void a(short[] paramArrayOfShort)
  {
    o = paramArrayOfShort;
    if (o == null) {
      return;
    }
    T = o.length * j.t - (c + (c >> 1) - 4);
    b.bl = 1L;
    b.aN = 1;
    S = 0;
  }
  
  public static void a(short[] paramArrayOfShort, byte paramByte)
  {
    int i2 = 0;
    for (int i1 = 0; i2 < af.v.length; i1 = i3)
    {
      i3 = i1;
      if (y[paramByte][0] != i2)
      {
        i3 = i1;
        if (y[paramByte][1] != i2)
        {
          i3 = i1;
          if (j.a(v[af.v[i2][7]], paramByte))
          {
            i3 = i1;
            if (j.a(w[af.v[i2][8]], paramByte))
            {
              i3 = i1;
              if (!j.a(v[i2], paramByte)) {
                i3 = i1 + 1;
              }
            }
          }
        }
      }
      i2 = (byte)(i2 + 1);
    }
    int i3 = 0;
    i2 = i1;
    i1 = i3;
    while (i1 < u.length)
    {
      i3 = i2;
      if (z[paramByte][0] != i1)
      {
        i3 = i2;
        if (z[paramByte][1] != i1)
        {
          i3 = i2;
          if (j.a(v[u[i1][7]], paramByte))
          {
            i3 = i2;
            if (j.a(w[u[i1][8]], paramByte))
            {
              i3 = i2;
              if (!j.a(w[i1], paramByte)) {
                i3 = i2 + 1;
              }
            }
          }
        }
      }
      i1 = (byte)(i1 + 1);
      i2 = i3;
    }
    if (i2 == 0)
    {
      al.ad = false;
      return;
    }
    short[] arrayOfShort = new short[i2];
    Object[][] arrayOfObject = (Object[][])Array.newInstance(Object.class, new int[] { i2, 4 });
    int[][] arrayOfInt = (int[][])Array.newInstance(Integer.TYPE, new int[] { i2, 2 });
    i1 = 0;
    i2 = 0;
    while (i2 < af.v.length)
    {
      i3 = i1;
      if (y[paramByte][0] != i2)
      {
        i3 = i1;
        if (y[paramByte][1] != i2)
        {
          i3 = i1;
          if (j.a(v[af.v[i2][7]], paramByte))
          {
            i3 = i1;
            if (j.a(w[af.v[i2][8]], paramByte))
            {
              i3 = i1;
              if (!j.a(v[i2], paramByte))
              {
                arrayOfShort[i1] = 290;
                arrayOfObject[i1] = { new Short((short)(i2 + 96)), new Byte(af.v[i2][1]), new Byte(af.v[i2][2]), new Byte(af.v[i2][0]), new Byte(af.v[i2][6]) };
                arrayOfInt[i1][0] = 2;
                arrayOfInt[i1][1] = i2;
                i3 = i1 + 1;
              }
            }
          }
        }
      }
      i2 = (byte)(i2 + 1);
      i1 = i3;
    }
    i2 = 0;
    if (i2 < u.length)
    {
      i3 = i1;
      Object localObject1;
      if (z[paramByte][0] != i2)
      {
        i3 = i1;
        if (z[paramByte][1] != i2)
        {
          i3 = i1;
          if (j.a(v[u[i2][7]], paramByte))
          {
            i3 = i1;
            if (j.a(w[u[i2][8]], paramByte))
            {
              i3 = i1;
              if (!j.a(w[i2], paramByte))
              {
                arrayOfShort[i1] = 289;
                localObject1 = "";
                if (u[i2][4] <= -1) {
                  break label849;
                }
                localObject1 = t[u[i2][4]] + ' ';
                Object localObject2 = new StringBuilder().append((String)localObject1);
                if (u[i2][4] >= 3) {
                  break label841;
                }
                localObject1 = j.b((short)395);
                label702:
                localObject1 = (String)localObject1;
                localObject2 = (String)localObject1 + u[i2][0];
                localObject1 = localObject2;
                if (i2 == 20) {
                  localObject1 = (String)localObject2 + ' ' + j.b((short)397);
                }
              }
            }
          }
        }
      }
      for (;;)
      {
        arrayOfObject[i1] = { new Short((short)(i2 + 133)), localObject1 };
        arrayOfInt[i1][0] = 1;
        arrayOfInt[i1][1] = i2;
        i3 = i1 + 1;
        i2 = (byte)(i2 + 1);
        i1 = i3;
        break;
        label841:
        localObject1 = "+";
        break label702;
        label849:
        if (i2 == 24) {
          localObject1 = j.b((short)398);
        }
      }
    }
    b.a((byte)5, false, null, arrayOfShort, arrayOfObject, arrayOfInt, null, (short)171, paramArrayOfShort, (short[][])null, af.y[paramByte][16]);
  }
  
  public static boolean a(x paramx, byte paramByte1, byte paramByte2, boolean paramBoolean)
  {
    if (paramByte1 == -1) {
      return false;
    }
    if (paramx.m != -1) {
      return false;
    }
    int i2 = af.v[paramByte1][4] * 10;
    int i1 = af.v[paramByte1][5] * 10;
    int i3 = af.v[paramByte1][6];
    int i4 = al.W[paramx.l];
    int i5 = A[paramx.l];
    int i6 = paramx.d - af.c;
    Object localObject;
    if ((i4 >= i2) && (i5 >= i1) && ((i6 >= i3) || (i3 == 0)))
    {
      localObject = al.W;
      i3 = paramx.l;
      localObject[i3] -= i2;
      localObject = al.br;
      i3 = paramx.l;
      localObject[i3] -= i2;
      localObject = A;
      i2 = paramx.l;
      localObject[i2] -= i1;
      localObject = m.d;
      i2 = paramx.l;
      localObject[i2] -= i1;
      if (paramByte1 == 24)
      {
        al.a(new aq(paramx.l, paramx.b, paramx.c, paramByte1, (byte)2, paramx.a), -1, true);
        af.a(paramx);
        g = true;
        i1 = B[n][0];
        j = i1;
        l = i1;
        i1 = B[n][1];
        k = i1;
        m = i1;
        return true;
      }
      paramx.m = paramByte1;
      paramx.n = paramByte2;
      i2 = af.v[paramByte1][6];
      if (paramByte1 == 1) {}
      for (i1 = 3;; i1 = 0)
      {
        paramx.o = ((short)((i2 + i1) * 25));
        if (paramByte1 == 1)
        {
          localObject = af.y[paramx.l];
          localObject[2] = ((short)(localObject[2] + 1));
          localObject = af.p;
          i1 = paramx.g;
          localObject[i1] = ((byte)(localObject[i1] + 1));
        }
        if ((paramByte2 != 23) || (paramx.l == al.G)) {
          break;
        }
        i1 = Math.abs(paramx.o) * af.v[paramx.m][6] << 1;
        if (al.W[paramx.l] <= i1) {
          break;
        }
        localObject = al.W;
        i2 = paramx.l;
        localObject[i2] -= i1;
        localObject = al.br;
        i2 = paramx.l;
        localObject[i2] -= i1;
        paramx.o = 0;
        break;
      }
    }
    if ((paramx.l == al.G) && (!paramBoolean))
    {
      if ((i6 >= i3) || (i3 <= 0)) {
        break label598;
      }
      localObject = new Integer(i3 - i6);
      short s1 = (short)(paramByte1 + 96);
      i1 = af.y[paramx.l][16];
      b.a((byte)0, new byte[] { 2, paramByte1 }, (short)247, new Object[] { localObject }, new short[] { 121 }, s1, i1);
    }
    for (;;)
    {
      return false;
      label598:
      a((byte)2, paramByte1, i2 - al.W[paramx.l], i1 - A[paramx.l], (short)(paramByte1 + 96), paramx.l);
    }
  }
  
  public static boolean a(x paramx, byte paramByte, int paramInt1, int paramInt2, boolean paramBoolean)
  {
    if ((paramByte == 24) && (af.y[paramx.l][12] > 0)) {
      if (paramx.l == al.G)
      {
        paramInt1 = af.y[paramx.l][16];
        b.a((byte)0, null, (short)230, null, new short[] { 121 }, (short)189, paramInt1);
      }
    }
    int i6;
    int i5;
    int i2;
    int i1;
    label510:
    label571:
    label587:
    label651:
    label653:
    do
    {
      do
      {
        do
        {
          return false;
          i6 = u[paramByte][3] * 10;
          i5 = u[paramByte][6] * 10;
        } while ((paramx.l != al.G) && (af.y[paramx.l][9] > 4) && (paramByte != 24) && (u[paramByte][4] != 1) && (u[paramByte][4] != 2) && ((al.W[paramx.l] - al.br[paramx.l] < i6) || (A[paramx.l] - m.d[paramx.l] < i5)));
        int i3 = al.W[paramx.l];
        int i4 = A[paramx.l];
        i2 = i3;
        i1 = i4;
        if (paramx.l == al.G) {
          break;
        }
        i2 = i3;
        i1 = i4;
        if (af.y[paramx.l][9] <= 4) {
          break;
        }
        i2 = i3;
        i1 = i4;
        if (paramByte == 24) {
          break;
        }
        i2 = i3;
        i1 = i4;
        if (u[paramByte][4] == 1) {
          break;
        }
        i2 = i3;
        i1 = i4;
        if (u[paramByte][4] == 2) {
          break;
        }
        i2 = al.W[paramx.l] - al.br[paramx.l];
        i1 = A[paramx.l] - m.d[paramx.l];
      } while ((i2 < i6) || (i1 < i5));
      if ((i2 >= i6) && (i1 >= i5))
      {
        paramx.q = ((byte)paramInt1);
        paramx.r = ((byte)paramInt2);
        if (u[paramByte][2] == paramByte)
        {
          paramx.h[paramInt1][paramInt2] = paramByte;
          paramx.p = ((short)(u[paramByte][5] * 15));
          localObject = al.W;
          paramInt1 = paramx.l;
          localObject[paramInt1] -= i6;
          localObject = A;
          paramInt1 = paramx.l;
          localObject[paramInt1] -= i5;
          if ((al.bu) || (paramByte != 24)) {
            break label651;
          }
          localObject = af.y[paramx.l];
          localObject[12] = ((short)(localObject[12] + 1));
          if (paramx.l == al.G) {
            break label653;
          }
          String str = j.b((short)494);
          paramInt1 = 0;
          localObject = str;
          if (paramInt1 >= al.aU.size()) {
            break label587;
          }
          paramInt2 = ((Byte)al.aU.elementAt(paramInt1)).byteValue();
          if (paramInt2 != paramx.l) {
            break label571;
          }
        }
        while (af.y[paramInt2][12] <= 0)
        {
          paramInt1 += 1;
          break label510;
          paramx.p = ((short)(u[paramByte][5] * -15));
          break;
        }
        Object localObject = " ";
        al.a((short)495, 0, new Object[] { j.b(al.ak[paramx.l]), new Byte(paramx.l), localObject }, new byte[] { 1, 24 }, (byte)-1, (byte)0, (short)165, 6);
        for (;;)
        {
          return true;
          paramx.f = -1;
        }
      }
    } while ((paramx.l != al.G) || (!paramBoolean));
    a((byte)1, paramByte, i6 - i2, i5 - i1, (short)(paramByte + 133), paramx.l);
    return false;
  }
  
  private static boolean a(Object paramObject)
  {
    Object localObject = al.a(H);
    int i1;
    switch (((Short)paramObject).shortValue())
    {
    default: 
    case 299: 
    case 300: 
    case 319: 
    case 337: 
      do
      {
        return false;
        al.c((aq)localObject);
        return true;
        a((aq)localObject);
        return true;
        ((aq)localObject).j = -1;
        ((aq)localObject).k = -1;
        ((aq)localObject).f = 2;
        return false;
        ((aq)localObject).f = 1;
        ((aq)localObject).j = -1;
        ((aq)localObject).k = -1;
      } while (((aq)localObject).m <= 0);
      al.af = ((aq)localObject).b;
      al.y = (aq)localObject;
      return false;
    case 322: 
      af.a(K);
      if (K.j[0] - af.c >= af.v[localObject.e][6])
      {
        ((aq)localObject).g = K.a;
        af.a(K);
        return false;
      }
      i1 = ((aq)localObject).e;
      i2 = af.y[localObject.a][16];
      b.a((byte)0, new byte[] { 2, i1 }, (short)246, null, new short[] { 121 }, (short)189, i2);
      return true;
    case 323: 
      paramObject = new Short(((aq)localObject).b);
      f.removeElement(paramObject);
      f.addElement(paramObject);
      return false;
    case 324: 
      paramObject = new Short(((aq)localObject).b);
      if (f.size() > 0)
      {
        localObject = al.a(((Short)f.firstElement()).shortValue());
        if ((localObject == null) || (((aq)localObject).e != 24)) {
          break;
        }
      }
      break;
    }
    for (int i2 = 1;; i2 = 0)
    {
      f.removeElement(paramObject);
      f.insertElementAt(paramObject, i2);
      return false;
      al.d((aq)localObject);
      return true;
      i2 = af.v[af.v[localObject.e][9]][4];
      int i3 = af.v[localObject.e][4];
      int i4 = af.v[af.v[localObject.e][9]][5];
      int i5 = af.v[localObject.e][5];
      i1 = af.v[localObject.e][9];
      paramObject = new Integer(i2 * 10 - i3 * 10);
      localObject = new Integer(i4 * 10 - i5 * 10);
      i2 = af.y[K.l][16];
      b.a((byte)34, new byte[] { 2, i1 }, (short)274, new Object[] { paramObject, localObject }, new short[] { 123, 132 }, (short)318, i2);
      return true;
    }
  }
  
  private static boolean a(Object paramObject, int paramInt1, int paramInt2)
  {
    int i1;
    short s1;
    label280:
    label396:
    label417:
    int i2;
    switch (((Short)paramObject).shortValue())
    {
    default: 
      return false;
    case 332: 
      paramInt1 = Math.abs(K.o) * af.v[K.m][6] << 1;
      if (al.W[K.l] >= paramInt1)
      {
        i1 = K.m;
        paramObject = new Integer(paramInt1);
        s1 = (short)(K.m + 96);
        paramInt1 = af.y[K.l][16];
        b.a((byte)11, new byte[] { 2, i1 }, (short)244, new Object[] { paramObject }, new short[] { 123, 132 }, s1, paramInt1);
      }
      for (;;)
      {
        return true;
        a((byte)2, K.m, paramInt1 - al.W[K.l], 0, (short)(K.m + 96), K.l);
      }
    case 333: 
      if (K.p > 0)
      {
        i1 = K.h[F][G];
        if (Math.abs(K.p) != 1) {
          break label396;
        }
        paramInt1 = 0;
        if (A[K.l] <= paramInt1) {
          break label417;
        }
        paramObject = new Integer(paramInt1);
        s1 = (short)(i1 + 133);
        paramInt1 = af.y[K.l][16];
        b.a((byte)13, new byte[] { 1, i1 }, (short)243, new Object[] { paramObject }, new short[] { 123, 132 }, s1, paramInt1);
      }
      for (;;)
      {
        return true;
        i1 = u[K.h[F][G]][1];
        break;
        paramInt1 = Math.abs(K.p) * u[i1][5];
        break label280;
        a((byte)1, i1, 0, paramInt1 - A[K.l], (short)(i1 + 133), K.l);
      }
    case 326: 
      K.q = -1;
      K.r = -1;
      K.p = 0;
      return false;
    case 325: 
      i2 = K.h[F][G];
      if (K.p >= 0)
      {
        paramInt2 = u[i2][3];
        paramInt1 = u[i2][6];
        paramInt2 = paramInt2 * 10 >> 1;
        paramInt1 = paramInt1 * 10 >> 1;
      }
      break;
    }
    for (;;)
    {
      paramObject = new Integer(paramInt2);
      Object localObject1 = new Integer(paramInt1);
      s1 = (short)(i2 + 133);
      paramInt1 = af.y[K.l][16];
      b.a((byte)9, new byte[] { 1, i2 }, (short)242, new Object[] { paramObject, localObject1 }, new short[] { 123, 132 }, s1, paramInt1);
      return true;
      if (K.p < 0)
      {
        paramInt2 = u[u[i2][1]][3];
        paramInt1 = u[u[i2][1]][6];
        paramInt2 = paramInt2 * 10 >> 1;
        paramInt1 = paramInt1 * 10 >> 1;
        continue;
        b.a((byte)25, new byte[] { 1, K.h[F][G] }, new short[] { 121, 126 }, (short)336, "", 10, false, true);
        return true;
        b.a((byte)26, new byte[] { 1, K.h[F][G] }, new short[] { 121, 126 }, (short)335, "", 10, false, true);
        return true;
        i2 = K.l;
        a(new short[] { 121, 122 }, i2);
        return true;
        int i3 = K.h[F][G];
        paramObject = j.a(K.e);
        b.a((byte)51, new byte[] { 1, i3 }, new short[] { 121, 126 }, (short)334, (String)paramObject, 30, true, true);
        paramInt1 = (o.h - y.t) / y.t;
        if (paramInt1 < o.e) {
          o.e = paramInt1;
        }
        return true;
        if (K.p != 0)
        {
          paramInt1 = af.y[K.l][16];
          b.a((byte)0, null, (short)265, null, new short[] { 121 }, (short)189, paramInt1);
          return true;
        }
        R = u[K.h[F][G]][1];
        int i4 = u[R][4];
        paramInt2 = al.al[paramInt1][paramInt2];
        paramInt1 = u[R][0];
        if ((i4 >= 0) && (i4 <= 2)) {
          paramInt1 = af.u[paramInt2][(i4 + 2)] * paramInt1;
        }
        for (;;)
        {
          i3 = R;
          paramObject = new Short((short)(R + 133));
          localObject1 = paramInt1 + t[i4];
          Object localObject2 = j.a((short)(i4 + 276));
          Object localObject3 = new Integer(u[R][3] * 10);
          Object localObject4 = new Integer(u[R][6] * 10);
          paramInt1 = af.y[K.l][16];
          b.a((byte)10, new byte[] { 1, i3 }, (short)275, new Object[] { paramObject, localObject1, localObject2, localObject3, localObject4 }, new short[] { 123, 132 }, (short)328, paramInt1);
          return true;
          if ((I < 0) && (K.p != 0))
          {
            paramInt1 = af.y[K.l][16];
            b.a((byte)0, null, (short)265, null, new short[] { 121 }, (short)189, paramInt1);
            return true;
          }
          int i5 = 0;
          i4 = 0;
          int i6;
          if (i4 < w.length)
          {
            if (i4 == 25) {
              i6 = i5;
            }
            for (;;)
            {
              i4 += 1;
              i5 = i6;
              break;
              if (!af.a(K, i4))
              {
                i6 = i5;
                if (u[i4][10] <= 1) {}
              }
              else
              {
                i6 = i5;
                if (j.a(w[i4], al.G))
                {
                  i6 = i5;
                  if (i4 != z[K.l][0])
                  {
                    i6 = i5;
                    if (i4 != z[K.l][1])
                    {
                      i6 = i5;
                      if (u[i4][2] == i4) {
                        if (((F == 1) && (G == 1)) || (u[i4][4] == 5))
                        {
                          i6 = i5;
                          if (F == 1)
                          {
                            i6 = i5;
                            if (G == 1)
                            {
                              i6 = i5;
                              if (u[i4][4] != 5) {}
                            }
                          }
                        }
                        else if ((!al.e(paramInt1, paramInt2)) || (i4 == 20))
                        {
                          i6 = i5;
                          if (!al.e(paramInt1, paramInt2))
                          {
                            i6 = i5;
                            if (i4 != 20) {}
                          }
                        }
                        else
                        {
                          i6 = i5 + 1;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
          if (i5 == 0)
          {
            if (al.e(paramInt1, paramInt2)) {
              break label3029;
            }
            if (K.i[20] > 0) {
              s1 = 268;
            }
          }
          for (;;)
          {
            paramInt1 = af.y[K.l][16];
            b.a((byte)0, null, s1, null, new short[] { 121 }, (short)189, paramInt1);
            return true;
            s1 = 267;
            continue;
            localObject1 = new short[i5];
            localObject2 = (Object[][])Array.newInstance(Object.class, new int[] { i5, 3 });
            localObject3 = (int[][])Array.newInstance(Integer.TYPE, new int[] { i5, 2 });
            i5 = 0;
            i4 = 0;
            if (i4 < w.length)
            {
              if (i4 == 25) {
                i6 = i5;
              }
              for (;;)
              {
                i4 = (byte)(i4 + 1);
                i5 = i6;
                break;
                if (!af.a(K, i4))
                {
                  i6 = i5;
                  if (u[i4][10] <= 1) {}
                }
                else
                {
                  i6 = i5;
                  if (j.a(w[i4], al.G))
                  {
                    i6 = i5;
                    if (i4 != z[K.l][0])
                    {
                      i6 = i5;
                      if (i4 != z[K.l][1])
                      {
                        i6 = i5;
                        if (u[i4][2] == i4) {
                          if (((F == 1) && (G == 1)) || (u[i4][4] == 5))
                          {
                            i6 = i5;
                            if (F == 1)
                            {
                              i6 = i5;
                              if (G == 1)
                              {
                                i6 = i5;
                                if (u[i4][4] != 5) {}
                              }
                            }
                          }
                          else if ((!al.e(paramInt1, paramInt2)) || (i4 == 20))
                          {
                            i6 = i5;
                            if (!al.e(paramInt1, paramInt2))
                            {
                              i6 = i5;
                              if (i4 != 20) {}
                            }
                          }
                          else
                          {
                            localObject1[i5] = 292;
                            localObject4 = new Short((short)(i4 + 133));
                            if (u[i4][4] != -1) {
                              break label2014;
                            }
                            paramObject = "";
                            localObject2[i5] = { localObject4, paramObject, new Integer(u[i4][3] * 10), new Integer(u[i4][6] * 10) };
                            localObject3[i5][0] = 1;
                            localObject3[i5][1] = i4;
                            i6 = i5 + 1;
                          }
                        }
                      }
                    }
                  }
                }
              }
              label2014:
              paramObject = new StringBuilder().append("+");
              int i7 = u[i4][0];
              label2070:
              StringBuilder localStringBuilder;
              if (u[i4][4] < 3)
              {
                i6 = af.u[J][(u[i4][4] + 2)];
                localStringBuilder = ((StringBuilder)paramObject).append(i7 * i6);
                if (u[i4][4] != 5) {
                  break label2131;
                }
              }
              label2131:
              for (paramObject = "%";; paramObject = "")
              {
                paramObject = (String)paramObject + t[u[i4][4]];
                break;
                i6 = 1;
                break label2070;
              }
            }
            paramObject = (short[][])null;
            paramInt1 = af.y[K.l][16];
            b.a((byte)7, false, null, (short[])localObject1, (Object[][])localObject2, (int[][])localObject3, null, (short)172, new short[] { 121, 122 }, (short[][])paramObject, paramInt1);
            return true;
            paramInt1 = 0;
            if (K.i[20] > 0)
            {
              paramInt1 = 1;
              if (K.p > 0) {
                if (K.h[K.q][K.r] == 20) {
                  break label2449;
                }
              }
            }
            label2449:
            for (paramInt1 = 1;; paramInt1 = 0)
            {
              paramInt2 = v.length;
              i4 = 0;
              paramInt2 -= 1;
              while (paramInt2 >= 0)
              {
                i5 = i4;
                if (j.a(v[paramInt2], K.l)) {
                  if (j.a(v[af.v[paramInt2][9]], K.l))
                  {
                    i5 = i4;
                    if (af.v[paramInt2][9] != paramInt2) {}
                  }
                  else if (af.v[paramInt2][3] == 0)
                  {
                    i5 = i4;
                    if (paramInt1 != 0)
                    {
                      i5 = i4;
                      if (af.v[paramInt2][3] != 0) {}
                    }
                  }
                  else
                  {
                    i5 = i4;
                    if (paramInt2 != y[K.l][0])
                    {
                      i5 = i4;
                      if (paramInt2 != y[K.l][1]) {
                        if (paramInt2 == 24)
                        {
                          i5 = i4;
                          if (af.x[24] <= 0)
                          {
                            i5 = i4;
                            if (af.y[K.l][16] == 0) {}
                          }
                        }
                        else
                        {
                          i5 = i4 + 1;
                        }
                      }
                    }
                  }
                }
                paramInt2 -= 1;
                i4 = i5;
              }
            }
            if (i4 == 0) {
              return false;
            }
            localObject1 = (short[][])Array.newInstance(Short.TYPE, new int[] { i4, 1 });
            localObject2 = new short[i4];
            localObject3 = (Object[][])Array.newInstance(Object.class, new int[] { i4, 4 });
            localObject4 = (int[][])Array.newInstance(Integer.TYPE, new int[] { i4, 2 });
            paramInt2 = (byte)(v.length - 1);
            i4 = 0;
            if (paramInt2 >= 0)
            {
              i5 = i4;
              if (j.a(v[paramInt2], K.l)) {
                if (j.a(v[af.v[paramInt2][9]], K.l))
                {
                  i5 = i4;
                  if (af.v[paramInt2][9] != paramInt2) {}
                }
                else if (af.v[paramInt2][3] == 0)
                {
                  i5 = i4;
                  if (paramInt1 != 0)
                  {
                    i5 = i4;
                    if (af.v[paramInt2][3] != 0) {}
                  }
                }
                else
                {
                  i5 = i4;
                  if (paramInt2 != y[K.l][0])
                  {
                    i5 = i4;
                    if (paramInt2 != y[K.l][1]) {
                      if (paramInt2 == 24)
                      {
                        i5 = i4;
                        if (af.x[24] <= 0)
                        {
                          i5 = i4;
                          if (af.y[K.l][16] == 0) {}
                        }
                      }
                      else
                      {
                        localObject2[i4] = 293;
                        localObject3[i4] = { new Short((short)(paramInt2 + 96)), new Integer(af.v[paramInt2][6]), new Integer(af.v[paramInt2][4] * 10), new Integer(af.v[paramInt2][5] * 10) };
                        localObject4[i4][0] = 2;
                        localObject4[i4][1] = paramInt2;
                        s1 = -1;
                        if (paramInt2 != 1) {
                          break label2933;
                        }
                        s1 = 295;
                        label2841:
                        if (s1 != -1) {
                          break label2960;
                        }
                      }
                    }
                  }
                }
              }
              label2933:
              label2960:
              for (paramObject = j.a((short)294, new Object[] { new Integer(af.v[paramInt2][1]), new Integer(af.v[paramInt2][2]), new Integer(af.v[paramInt2][0]) });; paramObject = j.a(s1))
              {
                localObject1[i4] = paramObject;
                i5 = i4 + 1;
                paramInt2 = (byte)(paramInt2 - 1);
                i4 = i5;
                break;
                if (paramInt2 == 2)
                {
                  s1 = 296;
                  break label2841;
                }
                if (paramInt2 != 24) {
                  break label2841;
                }
                s1 = 297;
                break label2841;
              }
            }
            paramInt1 = af.y[K.l][16];
            b.a((byte)8, false, null, (short[])localObject2, (Object[][])localObject3, (int[][])localObject4, null, (short)166, new short[] { 121, 122 }, (short[][])localObject1, paramInt1);
            return true;
            K.m = -1;
            return false;
            label3029:
            s1 = 266;
          }
        }
      }
      else
      {
        paramInt2 = 0;
        paramInt1 = 0;
      }
    }
  }
  
  static void b()
  {
    int i2;
    if (M)
    {
      int i1 = K.h[F][G];
      localObject = j.a(K.e);
      b.a((byte)51, new byte[] { 1, i1 }, new short[] { 121, 126 }, (short)334, (String)localObject, 30, true, true);
      M = false;
      i2 = (o.h - y.t) / y.t;
      if (i2 < o.e) {
        o.e = i2;
      }
    }
    p += 1;
    if ((p > 20) && (U > -al.f)) {
      U -= 4;
    }
    if (b.aq == true)
    {
      q += 1;
      if ((q > 20) && (r < b)) {
        r += 4;
      }
    }
    int i3;
    if ((l != h) || (m != i))
    {
      i3 = h;
      if (Math.abs(l - h) == 1)
      {
        i2 = l - h;
        label217:
        h = i3 + i2;
        i3 = i;
        if (Math.abs(m - i) != 1) {
          break label378;
        }
      }
      label378:
      for (i2 = m - i;; i2 = m - i >> 1)
      {
        i = i3 + i2;
        if ((l == h) && (m == i)) {
          a(j.a((short)B[n][10]));
        }
        switch (n)
        {
        case 9: 
        default: 
          return;
          i2 = l - h >> 1;
          break label217;
        }
      }
      F = af.A[0][n] + 1;
      G = af.A[1][n] + 1;
      I = K.h[F][G];
      i2 = al.a(K.b - 1 + F, al.n);
      i3 = al.a(K.c - 1 + G, al.o);
      J = al.al[i2][i3];
      if (I >= 0)
      {
        i2 = u[I][4];
        label500:
        if (I <= -1) {
          break label956;
        }
        if (i2 == -1) {
          break label1309;
        }
        if (i2 >= 3) {
          break label908;
        }
        localObject = String.valueOf(u[I][0] * af.u[J][(i2 + 2)]);
      }
    }
    label543:
    label908:
    label956:
    label1309:
    for (Object localObject = "" + t[i2] + '+' + (String)localObject;; localObject = "")
    {
      a(j.b(j.b((short)(I + 133)) + ": " + (String)localObject + ' ' + '(' + t[2] + '-' + String.valueOf(u[I][9]) + ") " + j.b((short)532) + t[0] + '+' + af.u[J][2] + ' ' + t[1] + '+' + af.u[J][3] + ' ' + t[2] + '+' + af.u[J][4]));
      for (;;)
      {
        F = af.A[0][n] + 1;
        G = af.A[1][n] + 1;
        i2 = af.e(F - 1, G - 1);
        N = al.R + al.p + 2 + (af.E[0][i2] * (al.p + 2) >> 2);
        i3 = al.S;
        int i4 = al.N;
        int i5 = al.q;
        O = (af.E[1][i2] * (al.p + 2) >> 2) + (i3 - i4 + i5);
        if ((n != 8) || (K.j[0] <= K.d + 2)) {
          break;
        }
        a(j.a((short)528));
        return;
        i2 = 0;
        break label500;
        String str = String.valueOf(u[I][0]);
        localObject = str;
        if (i2 != 5) {
          break label543;
        }
        localObject = str + '%';
        break label543;
        a(j.a((short)531, new Object[] { new Integer(af.u[J][2]), new Integer(af.u[J][3]), new Integer(af.u[J][4]) }));
      }
      al.y = al.a(((Short)f.elementAt(E)).shortValue());
      a(j.a((short)(al.y.e + 96)));
      return;
      if (x[K.l] != 0)
      {
        i3 = (s[af.t[K.l]] * (m.c[K.l] + 1) - al.bq[K.l]) / Math.max(1, af.y[K.l][17]);
        if (x[K.l] == 1) {}
        for (i2 = al.bp[K.l] + 96;; i2 = al.bp[K.l] + 133)
        {
          a(j.a((short)534, new Object[] { new Short((short)i2), new Integer(i3) }));
          return;
        }
      }
      o = null;
      return;
      if (K.m == -1) {
        break;
      }
      a(j.a((short)533, new Object[] { new Integer(K.o / Math.max(1, K.d)) }));
      return;
      if (K.j[0] <= K.d + 2) {
        break;
      }
      a(j.a((short)528));
      return;
      a();
      return;
    }
  }
  
  private static void b(ac paramac)
  {
    if ((b.aq == true) && (r >= b))
    {
      int i1 = Math.max(b.bi, b.bj) / 10;
      int i2 = Math.min(b.bi, b.bj) / 10;
      i.a(5, (a >> 1) - (i1 << 1), b - i2, i1 * 5, i2);
      return;
    }
    b.a(paramac, true);
  }
  
  private static boolean b(Object paramObject, int paramInt1, int paramInt2)
  {
    int i1 = 0;
    int i2 = 0;
    int i3;
    if (i1 < w.length)
    {
      if (i1 == 25) {
        i3 = i2;
      }
      label61:
      label196:
      do
      {
        do
        {
          do
          {
            do
            {
              do
              {
                do
                {
                  do
                  {
                    do
                    {
                      do
                      {
                        do
                        {
                          i1 = (byte)(i1 + 1);
                          i2 = i3;
                          break;
                          if (af.a(K, i1)) {
                            break label61;
                          }
                          i3 = i2;
                        } while (u[i1][10] <= 1);
                        i3 = i2;
                      } while (!j.a(w[i1], al.G));
                      i3 = i2;
                    } while (i1 == z[K.l][0]);
                    i3 = i2;
                  } while (i1 == z[K.l][1]);
                  i3 = i2;
                } while (u[i1][2] != i1);
                if (((F != 1) || (G != 1)) && (u[i1][4] != 5)) {
                  break label196;
                }
                i3 = i2;
              } while (F != 1);
              i3 = i2;
            } while (G != 1);
            i3 = i2;
          } while (u[i1][4] != 5);
          if ((al.e(paramInt1, paramInt2)) && (i1 != 20)) {
            break label232;
          }
          i3 = i2;
        } while (al.e(paramInt1, paramInt2));
        i3 = i2;
      } while (i1 != 20);
      label232:
      if (paramObject.equals(String.valueOf(i2))) {
        if (u[i1][4] != -1)
        {
          R = i1;
          i2 = u[i1][4];
          paramInt2 = al.al[paramInt1][paramInt2];
          paramInt1 = u[i1][0];
          if ((i2 < 0) || (i2 > 2)) {
            break label531;
          }
          paramInt1 *= af.u[paramInt2][(i2 + 2)];
        }
      }
    }
    label531:
    for (;;)
    {
      i1 = R;
      paramObject = new Short((short)(R + 133));
      String str = paramInt1 + t[i2];
      short[] arrayOfShort = j.a((short)(i2 + 276));
      Integer localInteger1 = new Integer(u[R][3] * 10);
      Integer localInteger2 = new Integer(u[R][6] * 10);
      short s1 = (short)(R + 133);
      paramInt1 = af.y[K.l][16];
      b.a((byte)10, new byte[] { 1, i1 }, (short)275, new Object[] { paramObject, str, arrayOfShort, localInteger1, localInteger2 }, new short[] { 123, 132 }, s1, paramInt1);
      return true;
      return !a(K, i1, F, G, true);
      i3 = i2 + 1;
      break;
      return false;
    }
  }
  
  private static void c(ac paramac)
  {
    paramac.a(65793 * (Math.abs(12 - b.aN) << 1) * 9);
    switch (n)
    {
    }
    do
    {
      do
      {
        return;
        al.b(paramac, N, O);
        if (al.b() > 2) {}
        for (i1 = 16777215;; i1 = 0)
        {
          paramac.a(i1);
          paramac.e(P, Q, 0, 0);
          return;
        }
      } while (al.y == null);
      j.a(paramac, h - (al.r >> 1), i - al.s - (al.s >> 1), al.r, al.s, false, 6710886);
      al.a(paramac, al.y, h - (al.r >> 1), i - al.s - (al.s >> 1), true, true, false);
      return;
    } while (L.size() <= 0);
    int i1 = Math.min(al.r * 4, L.size() * al.r);
    int i3 = Math.max(5, h - (al.r >> 1) - (i1 >> 1));
    int i4 = i - al.s * 2;
    j.a(paramac, i3, i4, i1, al.s, false, 6710886);
    if (L.size() == 0) {
      i1 = 0;
    }
    for (;;)
    {
      int i5 = L.size();
      int i2 = 0;
      while (i2 < i5)
      {
        aq localaq = al.a(((Short)L.elementAt(i2)).shortValue());
        al.a(paramac, localaq, i3 + i2 * i1, i4, false, false, false);
        j.a(paramac, t[4] + String.valueOf(af.v[localaq.e][6]), i2 * i1 + i3 + 1, al.s + i4 - j.u - 1);
        i2 += 1;
      }
      break;
      if (L.size() == 1) {
        i1 = al.r;
      } else {
        i1 = (i1 - al.r) / (L.size() - 1);
      }
    }
  }
  
  public static boolean c()
  {
    b.aV = 999999;
    g = true;
    if (o.u == null) {
      return false;
    }
    Object localObject = o.u;
    int i2 = al.a(F + K.b - 1, al.n);
    int i3 = al.a(G + K.c - 1, al.o);
    switch (o.s)
    {
    default: 
    case 62: 
    case 11: 
    case 13: 
      do
      {
        for (;;)
        {
          return false;
          al.e(al.a(H));
          return false;
          if (localObject.equals(String.valueOf(123)))
          {
            localObject = al.W;
            i2 = K.l;
            localObject[i2] -= (Math.abs(K.o) * af.v[K.m][6] << 1);
            K.o = 0;
          }
        }
      } while (!localObject.equals(String.valueOf(123)));
      if (K.p > 0)
      {
        i2 = K.h[F][G];
        if (Math.abs(K.p) != 1) {
          break label402;
        }
        i2 = 0;
        localObject = A;
        i3 = K.l;
        localObject[i3] -= i2;
        localObject = K;
        if (K.p <= 0) {
          break label425;
        }
      }
      for (i2 = 1;; i2 = -1)
      {
        ((x)localObject).p = ((short)i2);
        break;
        i2 = u[K.h[F][G]][1];
        break label315;
        i3 = Math.abs(K.p);
        i2 = u[i2][5] * i3;
        break label330;
      }
    case 6: 
      return a(localObject, i2, i3);
    case 7: 
      return b(localObject, i2, i3);
    case 10: 
      return (localObject.equals(String.valueOf(123))) && (!a(K, R, F, G, true));
    case 8: 
      label315:
      label330:
      label402:
      label425:
      if (K.i[20] > 0) {
        if (K.p > 0) {
          if (K.h[K.q][K.r] != 20) {
            i2 = 1;
          }
        }
      }
      break;
    }
    for (;;)
    {
      label530:
      i3 = v.length - 1;
      int i5;
      for (int i4 = 0; i3 >= 0; i4 = i5)
      {
        i5 = i4;
        if (j.a(v[i3], al.G)) {
          if (j.a(v[af.v[i3][9]], al.G))
          {
            i5 = i4;
            if (af.v[i3][9] != i3) {}
          }
          else if (af.v[i3][3] == 0)
          {
            i5 = i4;
            if (i2 != 0)
            {
              i5 = i4;
              if (af.v[i3][3] != 0) {}
            }
          }
          else
          {
            i5 = i4;
            if (i3 != y[K.l][0])
            {
              i5 = i4;
              if (i3 != y[K.l][1]) {
                if (i3 == 24)
                {
                  i5 = i4;
                  if (af.x[24] <= 0)
                  {
                    i5 = i4;
                    if (af.y[K.l][16] == 0) {}
                  }
                }
                else
                {
                  if (localObject.equals(String.valueOf(i4)))
                  {
                    if (!a(K, (byte)i3, (byte)1, false))
                    {
                      return true;
                      i2 = 0;
                      break label530;
                    }
                    return false;
                  }
                  i5 = i4 + 1;
                }
              }
            }
          }
        }
        i3 -= 1;
      }
      if (!localObject.equals(String.valueOf(123))) {
        break;
      }
      t.a(K, F, G, true);
      af.a(K);
      return false;
      byte b1 = al.G;
      int i1 = 0;
      for (i2 = 0; i1 < af.v.length; i2 = i3)
      {
        i3 = i2;
        if (y[al.G][0] != i1)
        {
          i3 = i2;
          if (y[al.G][1] != i1)
          {
            i3 = i2;
            if (j.a(v[af.v[i1][7]], b1))
            {
              i3 = i2;
              if (j.a(w[af.v[i1][8]], b1))
              {
                i3 = i2;
                if (!j.a(v[i1], b1))
                {
                  if (localObject.equals(String.valueOf(i2)))
                  {
                    if ((al.bp[b1] != i1) || (x[b1] != 1)) {
                      al.bp[b1] = i1;
                    }
                    x[b1] = 1;
                    return false;
                  }
                  i3 = i2 + 1;
                }
              }
            }
          }
        }
        i1 = (byte)(i1 + 1);
      }
      i1 = 0;
      while (i1 < u.length)
      {
        i3 = i2;
        if (z[al.G][0] != i1)
        {
          i3 = i2;
          if (z[al.G][1] != i1)
          {
            i3 = i2;
            if (j.a(v[u[i1][7]], b1))
            {
              i3 = i2;
              if (j.a(w[u[i1][8]], b1))
              {
                i3 = i2;
                if (!j.a(w[i1], b1))
                {
                  if (localObject.equals(String.valueOf(i2)))
                  {
                    if ((al.bp[b1] != i1) || (x[b1] != 2)) {
                      al.bp[b1] = i1;
                    }
                    x[b1] = 2;
                    return false;
                  }
                  i3 = i2 + 1;
                }
              }
            }
          }
        }
        i1 = (byte)(i1 + 1);
        i2 = i3;
      }
      x[b1] = 0;
      al.bp[b1] = -1;
      break;
      if (!localObject.equals(String.valueOf(123))) {
        break;
      }
      af.a(al.a(H));
      E = 0;
      d(j.f);
      if (f.size() > 0) {}
      for (n = 12;; n = 10)
      {
        j = B[n][0];
        k = B[n][1];
        al.y = null;
        af.a(K);
        break;
      }
      if (!localObject.equals(String.valueOf(123))) {
        break;
      }
      return t.a(al.a(H), (Vector)al.ae.get(al.bj[al.G]), false) != 3;
      localObject = (String)localObject;
      if (((String)localObject).length() <= 0) {
        break;
      }
      i2 = Math.min(Integer.valueOf((String)localObject).intValue(), al.W[al.G] >> 1);
      localObject = A;
      i3 = al.G;
      localObject[i3] += i2;
      localObject = al.W;
      i3 = al.G;
      localObject[i3] -= (i2 << 1);
      break;
      localObject = (String)localObject;
      if (((String)localObject).length() <= 0) {
        break;
      }
      i2 = Math.min(Integer.valueOf((String)localObject).intValue(), A[al.G]);
      localObject = A;
      i3 = al.G;
      localObject[i3] -= i2;
      localObject = al.W;
      i3 = al.G;
      localObject[i3] = ((i2 >> 1) + localObject[i3]);
      break;
      localObject = (String)localObject;
      if (((String)localObject).length() > 0) {
        K.e = j.b((String)localObject);
      }
      i2 = B[n][0];
      j = i2;
      l = i2;
      i2 = B[n][1];
      k = i2;
      m = i2;
      break;
      return a(localObject);
      i2 = 1;
      continue;
      i2 = 0;
    }
  }
  
  private static void d()
  {
    aq localaq = al.a(H);
    short[] arrayOfShort2;
    int i2;
    if (localaq != null)
    {
      arrayOfShort2 = new short[20];
      if (localaq.e == 24) {
        break label456;
      }
      if (localaq.f != 1) {
        break label436;
      }
      arrayOfShort2[0] = 319;
      i2 = 1;
    }
    for (;;)
    {
      int i3 = i2;
      if (localaq.f != 33)
      {
        i3 = i2;
        if (af.v[localaq.e][9] != localaq.e)
        {
          i3 = i2;
          if (j.a(v[af.v[localaq.e][9]], localaq.a))
          {
            i3 = (byte)(i2 + 1);
            arrayOfShort2[i2] = 318;
          }
        }
      }
      i2 = (byte)(i3 + 1);
      arrayOfShort2[i3] = 299;
      if (localaq.e == 24)
      {
        i3 = (byte)(i2 + 1);
        arrayOfShort2[i2] = 310;
        i2 = i3;
      }
      for (;;)
      {
        i3 = i2;
        if (localaq.e != 0) {
          if (localaq.r != null)
          {
            i3 = i2;
            if (localaq.r.size() > 0) {}
          }
          else
          {
            i3 = (byte)(i2 + 1);
            arrayOfShort2[i2] = 300;
          }
        }
        i2 = i3;
        if (al.L[localaq.c][localaq.d] != localaq.g)
        {
          i2 = (byte)(i3 + 1);
          arrayOfShort2[i3] = 322;
        }
        int i4 = i2;
        if (K.k.size() > 1)
        {
          i4 = i2;
          if (localaq.e != 24)
          {
            i3 = i2;
            if (K.k.indexOf(new Short(localaq.b)) < K.k.size() - 1)
            {
              i3 = (byte)(i2 + 1);
              arrayOfShort2[i2] = 323;
            }
            i4 = i3;
            if (K.k.indexOf(new Short(localaq.b)) > 0)
            {
              i2 = (byte)(i3 + 1);
              arrayOfShort2[i3] = 324;
            }
          }
        }
        for (;;)
        {
          short[] arrayOfShort1 = new short[i2];
          System.arraycopy(arrayOfShort2, 0, arrayOfShort1, 0, i2);
          int i1 = localaq.e;
          arrayOfShort2 = j.a((short)(localaq.e + 96));
          i2 = af.y[localaq.a][16];
          b.a((byte)1, new byte[] { 2, i1 }, arrayOfShort1, arrayOfShort2, new short[] { 121, 122 }, i2);
          return;
          label436:
          arrayOfShort2[0] = 337;
          i2 = 1;
          break;
          i2 = i4;
        }
      }
      label456:
      i2 = 0;
    }
  }
  
  private static void d(ac paramac)
  {
    al.y = null;
    al.a(paramac, true, 0);
    j.a(j.f, j.z[15][2], j.z[14][3], a - (j.z[15][2] << 1), b - (j.z[14][3] << 1), af.y[K.l][16], -2, true);
    Object localObject;
    int i2;
    int i3;
    int i4;
    int i5;
    label334:
    int i6;
    int i7;
    if ((K.q != -1) && (K.r != -1) && (K.h[K.q][K.r] > -1) && (K.p != 0))
    {
      localObject = u[K.h[K.q][K.r]];
      i1 = af.e(K.q - 1, K.r - 1);
      i2 = c + (af.E[0][i1] * (al.p + 2) >> 2) - (j.z[1][2] >> 1);
      i3 = d;
      i3 = (af.E[1][i1] * al.q >> 1) + i3 - (j.z[1][3] >> 1);
      i4 = j.z[1][2];
      i5 = Math.abs(K.p);
      if (K.p > 0)
      {
        i1 = localObject[5];
        a(paramac, i2, i3, i4, 100 - i5 * 100 / (i1 * 15), af.y[K.l][16], true);
        if (K.p <= 0) {
          break label868;
        }
        i1 = K.h[K.q][K.r];
        localObject = j.b((short)(i1 + 133));
        j.a(paramac, (String)localObject, i2 - (((String)localObject).length() * j.t - al.p >> 1), i3 + 4);
      }
    }
    else
    {
      al.a(j.f, K.l, 0, 0);
      localObject = t[4] + String.valueOf(K.d);
      i2 = ((String)localObject).length() * j.t;
      i4 = j.t + 3 + 4 + (j.t << 2);
      i1 = c - (i2 + 4 >> 1) - i4 >> 1;
      i3 = b >> 3;
      i4 = Math.min(c + (i2 + 4 >> 1) + i1, a - i4 - 1);
      i5 = Math.max(d - 64, 1);
      a(paramac, new int[] { 1, 2 }, i4, i5 - i3);
      i1 = Math.max(i1, 1);
      i4 = Math.max(d - 64, 1);
      a(paramac, new int[] { 0, 5 }, i1, i4 - i3);
      i4 = c;
      i5 = Math.max(d - al.q * 3 - j.u, 5);
      i6 = j.u;
      i7 = af.y[K.l][16];
      if (K.j[0] <= K.d + 2) {
        break label876;
      }
    }
    label868:
    label876:
    for (int i1 = 16711680;; i1 = -1)
    {
      j.a(paramac, i4 - (i2 >> 1) - 2, i5 - 1 - i3, i2 + 4, i6 + 2, i7, i1, false);
      j.a(paramac, (String)localObject, c - (i2 >> 1), Math.max(d - al.q * 3 - j.u, 5) - i3);
      B[11][1] = (d - al.q * 3 - 3 - i3);
      C[11] = { c - (i2 >> 1) - 2, Math.max(d - al.q * 3 - j.u, 5) - 1 - i3, i2 + 4, j.u + 2 };
      if (b.aq == true)
      {
        localObject = C[11];
        localObject[0] -= 20;
        localObject = C[11];
        localObject[1] -= 20;
        localObject = C[11];
        localObject[2] += 40;
        localObject = C[11];
        localObject[3] += 40;
      }
      e(paramac);
      return;
      i1 = u[localObject[1]][5];
      break;
      i1 = localObject[1];
      break label334;
    }
  }
  
  private static void e(ac paramac)
  {
    f = new Vector();
    L = new Vector();
    Object localObject = (Vector)al.ae.get(al.bj[K.l]);
    int i1;
    if (localObject != null)
    {
      i2 = ((Vector)localObject).size();
      i1 = 0;
      while (i1 < i2)
      {
        aq localaq = (aq)al.K.get(((Vector)localObject).elementAt(i1));
        if (localaq.g == K.a) {
          L.addElement(new Short(localaq.b));
        }
        i1 += 1;
      }
    }
    f = K.k;
    int i7 = Math.min(j.z[2][2] * 2 + f.size() * al.r + j.z[15][2] * 2, a - 4);
    int i2 = i7 - j.z[2][2] * 2 - j.z[15][2] * 2;
    int i3 = al.s;
    int i6 = c - (i7 >> 1);
    int i4 = Math.min(d + al.q + (al.q >> 1) + (b - (d + al.q + (al.q >> 1)) >> 1) - (i3 >> 1), b - i3 - j.z[14][3]);
    int i5 = al.r + i6 + j.z[15][2];
    j.a(paramac, i6, i4, i7, i3, af.y[K.l][16], -1, true);
    j.a(paramac, i5, i4, i2, i3, af.y[K.l][16], -2, true);
    if (x[K.l] != 0)
    {
      int i8 = al.bq[K.l] * 100 / (s[af.t[K.l]] * (m.c[K.l] + 1));
      localObject = j.z;
      if (x[K.l] == 1)
      {
        i1 = 2;
        int i9 = localObject[i1][2];
        localObject = j.z;
        if (x[K.l] != 1) {
          break label892;
        }
        i1 = 2;
        label434:
        int i10 = localObject[i1][3];
        if (x[K.l] != 1) {
          break label897;
        }
        i1 = 2;
        label458:
        j.a(paramac, i1, al.bp[K.l], i6 + i7 - j.z[2][2] + (j.z[2][2] >> 1) - (i9 >> 1), (j.z[2][3] >> 1) + i4 - (i10 >> 1), i9 - j.z[2][2] >> 1, i9 - j.z[2][2] >> 1, i10 - j.z[2][3] >> 1, i10 - j.z[2][3] >> 1);
        a(paramac, i6 + i7 - j.z[2][2], i4 + i3 - 1, j.z[2][2], i8, af.y[K.l][16], false);
      }
    }
    else
    {
      B[13][0] = (i6 + i7 - (j.z[2][2] >> 1));
      B[13][1] = ((i3 >> 1) + i4);
      C[13] = { i6 + i7 - j.z[2][2], i4, i7, i3 };
      if (K.m != -1) {
        break label902;
      }
      j.a(paramac, t[4] + String.valueOf(Math.max(0, af.c)), (al.r >> 1) + i6 - j.t - (j.t >> 1), (i3 >> 1) + i4 - (j.u >> 1));
      label763:
      B[10][0] = ((al.r >> 1) + i6);
      B[10][1] = ((i3 >> 1) + i4);
      C[10] = { i6, i4, al.r, i3 };
      if (f.size() != 0) {
        break label1026;
      }
      i1 = 0;
    }
    for (;;)
    {
      i6 = f.size();
      i2 = 0;
      while (i2 < i6)
      {
        al.a(paramac, al.a(((Short)f.elementAt(i2)).shortValue()), i5 + i2 * i1, i4, false, false, false);
        i2 += 1;
      }
      i1 = 1;
      break;
      label892:
      i1 = 1;
      break label434;
      label897:
      i1 = 1;
      break label458;
      label902:
      j.a(paramac, 2, K.m, i6, i4);
      i7 = K.o;
      if (af.v[K.m][6] == 0)
      {
        i1 = 1;
        i1 = i7 * 100 / i1;
        a(paramac, i6, i4 + i3 - 1, al.r, 100 - i1, af.y[K.l][16], false);
        break label763;
      }
      if (K.m == 1) {}
      for (i1 = 3;; i1 = 0)
      {
        i1 = (i1 + af.v[K.m][6]) * 25;
        break;
      }
      label1026:
      if (f.size() == 1) {
        i1 = al.r;
      } else {
        i1 = (i2 - al.r) / (f.size() - 1);
      }
    }
    B[12][0] = ((al.r >> 1) + i5);
    B[12][1] = ((i3 >> 1) + i4);
    D = i1;
    C[12] = { i5, i4, i1 * i6, i3 };
  }
}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */