package com.herocraft.game.revival2;

import java.util.Vector;

final class x
{
  public short a;
  public final short b;
  public final short c;
  public short d;
  public short[] e;
  public byte f;
  public byte g;
  public final byte[][] h;
  public final byte[] i;
  public final short[] j;
  public final Vector k;
  public byte l;
  public byte m;
  public byte n;
  public short o;
  public short p;
  public byte q;
  public byte r;
  public byte s;
  
  x(byte paramByte, short paramShort1, short paramShort2, short paramShort3, short[] paramArrayOfShort)
  {
    this.l = paramByte;
    this.d = paramShort3;
    this.b = paramShort1;
    this.c = paramShort2;
    this.e = paramArrayOfShort;
    this.k = new Vector();
    this.h = new byte[][] { { -1, -1, -1 }, { -1, -1, -1 }, { -1, -1, -1 } };
    this.i = new byte[ak.u.length];
    this.j = new short[] { 0, 0, 0, 0, 0, 0 };
    this.m = -1;
    this.q = -1;
    this.r = -1;
  }
}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\x.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */