package com.herocraft.game.revival2;

public class InvalidRecordIDException
  extends RecordStoreException
{}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\InvalidRecordIDException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */