package com.herocraft.game.revival2;

final class ar
{
  private String a = null;
  private ag b = new ag();
  private ag c = new ag();
  private ao d;
  private boolean e = false;
  private boolean f = false;
  
  public final String a()
  {
    return this.a;
  }
  
  public final boolean b()
  {
    return this.e;
  }
  
  public final boolean c()
  {
    return this.f;
  }
  
  public final void d()
  {
    j.b();
    this.d = new ao();
    ah.a();
    ah.a(this.d);
  }
}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */