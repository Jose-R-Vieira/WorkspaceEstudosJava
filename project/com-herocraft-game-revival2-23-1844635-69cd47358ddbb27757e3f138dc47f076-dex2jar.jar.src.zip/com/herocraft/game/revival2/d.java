package com.herocraft.game.revival2;

public abstract class d
  extends e
{
  public static int f(int paramInt)
  {
    return paramInt;
  }
  
  protected abstract void a(ac paramac);
  
  protected void c(int paramInt1, int paramInt2) {}
  
  protected void d(int paramInt) {}
  
  protected void d(int paramInt1, int paramInt2) {}
  
  protected void e(int paramInt) {}
  
  protected void e(int paramInt1, int paramInt2) {}
  
  protected void w() {}
  
  protected void x() {}
  
  public final void y()
  {
    if (AppCtrl.midletview != null) {
      AppCtrl.midletview.a(this);
    }
  }
}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */