package com.herocraft.game.revival2;

public final class as
{
  public final byte a;
  public final short b;
  public final short c;
  public final short d;
  public final byte e;
  public final byte f;
  public final byte g;
  public short h;
  public final byte i;
  
  public as(byte paramByte1, short paramShort1, short paramShort2, short paramShort3, byte paramByte2, byte paramByte3, byte paramByte4, byte paramByte5)
  {
    this.a = paramByte1;
    this.b = paramShort1;
    this.c = paramShort2;
    this.d = paramShort3;
    this.e = paramByte2;
    this.f = paramByte3;
    this.g = paramByte4;
    this.i = paramByte5;
    this.h = 0;
  }
}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */