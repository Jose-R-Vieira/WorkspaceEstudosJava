package com.herocraft.game.revival2;

public class y
{
  protected static byte s;
  public static byte t = 14;
  public static byte u = 25;
  protected static byte v = 10;
  protected static byte w = 32;
  protected static byte x = 20;
  protected static byte y = 20;
  public static final short[][] z;
  
  static
  {
    short[] arrayOfShort1 = { 0, 0, 62, 32, 6, 2 };
    short[] arrayOfShort2 = { 0, 0, 62, 52, 6, 3 };
    short[] arrayOfShort3 = { 124, 96, 62, 32, 1, 2 };
    short[] arrayOfShort4 = { 48, 144, 48, 48, 6, 4 };
    short[] arrayOfShort5 = { 0, 96, 62, 32, 2, 2 };
    short[] arrayOfShort6 = { 0, 40, 36, 40, 2, 1 };
    short[] arrayOfShort7 = { 0, 0, (short)t, (short)u, (short)s, 0 };
    short[] arrayOfShort8 = { 0, 0, 40, 40, 4, 1 };
    short[] arrayOfShort9 = { 0, 132, 18, 12, 4, 1 };
    short[] arrayOfShort10 = { 618, 40, 14, 14, 1, 1 };
    short[] arrayOfShort11 = { 72, 40, 8, 50, 4, 1 };
    short[] arrayOfShort12 = { 94, 168, 94, 48, 4, 2 };
    short[] arrayOfShort13 = { 104, 72, 14, 14, 2, 1 };
    short[] arrayOfShort14 = { 248, 192, 62, 32, 1, 2 };
    short[] arrayOfShort15 = { 132, 80, 36, 64, 1, 1 };
    short[] arrayOfShort16 = { 354, 260, 14, 24, 3, 3 };
    short[] arrayOfShort17 = { 0, 0, 76, 76, 1, 6 };
    short[] arrayOfShort18 = { 0, 0, 80, 94, 7, 5 };
    short[] arrayOfShort19 = { 214, 156, 34, 26, 1, 3 };
    short[] arrayOfShort20 = { 276, 156, 34, 26, 1, 3 };
    short[] arrayOfShort21 = { 334, 284, 26, 14, 1, 3 };
    z = new short[][] { arrayOfShort1, arrayOfShort2, { 0, 0, 48, 48, 8, 4 }, { 124, 208, 62, 52, 4, 3 }, arrayOfShort3, { 72, 90, 18, 18, 3, 1 }, arrayOfShort4, arrayOfShort5, arrayOfShort6, arrayOfShort7, { 0, 120, 18, 12, 4, 1 }, arrayOfShort8, arrayOfShort9, arrayOfShort10, { 104, 40, 50, 8, 1, 1 }, arrayOfShort11, { 264, 199, 30, 18, 1, 2 }, arrayOfShort12, arrayOfShort13, { 248, 260, 44, 26, 2, 3 }, arrayOfShort14, arrayOfShort15, arrayOfShort16, arrayOfShort17, arrayOfShort18, arrayOfShort19, arrayOfShort20, { 338, 156, 34, 26, 1, 3 }, arrayOfShort21 };
  }
}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */