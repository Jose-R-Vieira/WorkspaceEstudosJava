package com.herocraft.game.revival2;

import java.util.Vector;

public final class aq
{
  public final byte a;
  public short b;
  public short c;
  public short d;
  public byte e;
  public byte f;
  public short g;
  public byte h;
  public byte i;
  public short j = -1;
  public short k = -1;
  public short l;
  public byte m;
  public byte n;
  public byte o;
  public byte p;
  public short q;
  public Vector r;
  public int s;
  
  public aq(byte paramByte1, short paramShort1, short paramShort2, byte paramByte2, byte paramByte3, short paramShort3)
  {
    this.a = paramByte1;
    this.c = paramShort1;
    this.d = paramShort2;
    this.e = paramByte2;
    this.f = paramByte3;
    this.g = paramShort3;
    this.n = 1;
    this.m = 1;
    this.o = 0;
    this.p = 0;
    if (af.v[paramByte2][10] == 4) {
      this.r = new Vector();
    }
    this.s = -1;
  }
}


/* Location:              C:\Users\jose.rodrigues\Desktop\apktool\dex2jar-2.0\dex2jar-2.0\com-herocraft-game-revival2-23-1844635-69cd47358ddbb27757e3f138dc47f076-dex2jar.jar!\com\herocraft\game\revival2\aq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */