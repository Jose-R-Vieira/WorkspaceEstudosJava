package com.herocraft.game.revival2.lite;

public class a
  extends c
{
  private String f;
  private String g;
  private String h;
  private String i;
  private String j;
  private String k;
  
  public a(b paramb)
  {
    super(paramb);
  }
  
  private void c()
  {
    this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(1, false);
    this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(0, true);
    String str1 = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(5) + "";
    String str3 = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(this.j + str1);
    long l;
    try
    {
      l = Long.parseLong(str3);
      str1 = str1 + this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.c("2d2p267L");
      if (l == this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(str1.getBytes())) {
        break label158;
      }
      throw new Exception();
    }
    catch (Exception localException)
    {
      this.jdField_a_of_type_Int = 8;
      if (str3 != null) {
        break label181;
      }
    }
    String str2 = this.g;
    for (;;)
    {
      this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(str2);
      return;
      label158:
      this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(0, 1L);
      this.jdField_a_of_type_Int = 9;
      str2 = this.i;
      continue;
      label181:
      str2 = this.f;
      l = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(8) + 1L;
      if (l > 3L)
      {
        this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(6, 0L);
        this.jdField_a_of_type_Int = 3;
      }
      else
      {
        this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(8, l + 1L);
      }
    }
  }
  
  public void a()
    throws Exception
  {
    super.a();
    this.k = this.e;
    this.f = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a("2de027XTusil+pz9lPid+Q", "2ZXTstu30raW4o2t277MpcO6mu6G48OzxrTXv96tyObGldiLq8avyKDU9Jr1gaHJqN67m+mM7Y7mg+fHssHhmP2Jp4fTodj4mf6f9pin");
    this.g = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a("2cCjzKLErd+y7Yvqg++K7rHSvdO92LvPpsmn", "2Z/cs8aqzqCH89Ow37HfutmtjfmWtsKqz++c+Yv9mOrE5KfPqsmiguuF8ZTmiO2Zucqv26/GqM+8nP2T99ej0aiI6Y7vhujG");
    this.h = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a("2de027XTusil+pT7j+aA+Q", "2ZvPoID2k+GI7pe3w6vO7p7rmfqS84DlxazY+JHiwqzJqs+8z67cpYXxnr7dstyy17TA4JT726/HooLLpdG0xqjNuZc");
    this.i = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a("2da12rTSu8mk+4j9nv2Y65g", "2eKy3rvaqczsnvuI/J3vm7vPp8LiheSJ7Mytw6eH4ozmifDQpMypie+a9pq6zKnbqMGuwOHBlf2c8pnqyw");
    this.j = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a("2dKx3rDWv82g/4r4lA", "2eqC9oLyyOfIq8Sq3rvVoY/ngvCf/I7vif3TsN+ynf6a6ca10KLUuN2phvOd8Z79lqnApJk");
    if (this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(6) == 1L)
    {
      this.jdField_a_of_type_Int = 4;
      a(0);
    }
  }
  
  public void a(int paramInt)
  {
    switch (this.jdField_a_of_type_Int)
    {
    case 5: 
    case 7: 
    default: 
      super.a(paramInt);
    case 6: 
      do
      {
        return;
        if (paramInt == 0)
        {
          this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(0, false);
          this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(1, false);
          this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(this.c);
          this.jdField_a_of_type_Int = 7;
        }
      } while (paramInt != 1);
      this.jdField_a_of_type_Int = 5;
      return;
    case 8: 
      this.jdField_a_of_type_Int = 4;
      a(paramInt);
      return;
    case 4: 
      this.jdField_a_of_type_Int = 6;
      this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(0, true);
      this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(1, true);
      this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(this.h);
      return;
    }
    this.jdField_a_of_type_Int = 5;
  }
  
  public boolean a()
  {
    if (this.jdField_a_of_type_Int == 7) {
      c();
    }
    return super.a();
  }
  
  protected void b()
  {
    String str = System.getProperty(this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.c("2cyhyKvZttO33qrDrMLsnPCR5YPsnvM")) + System.currentTimeMillis();
    long l = this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(str.getBytes());
    this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(5, l);
    this.e = (this.k + "_" + l);
    super.b();
    if (this.jdField_a_of_type_Int == 4)
    {
      this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(8, 0L);
      this.jdField_a_of_type_ComHerocraftGameRevival2LiteB.a(6, 1L);
    }
  }
}


/* Location:              C:\WPrograming\jd-gui-windows-1.4.0\revival2ci_43in8y47-dex2jar.jar!\com\herocraft\game\revival2\lite\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */