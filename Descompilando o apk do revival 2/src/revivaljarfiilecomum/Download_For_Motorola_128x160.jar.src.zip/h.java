import java.util.Vector;

public final class h
{
  public short a;
  public final short b;
  public final short c;
  public short d;
  public final byte[] a;
  public byte a;
  public byte b;
  public final byte[][] a;
  public final byte[] b;
  public final short[] a;
  public final Vector a;
  public byte c;
  public byte d;
  public byte e;
  public short e;
  public short f;
  public byte f;
  public byte g;
  public short g;
  
  public h(byte paramByte, short paramShort1, short paramShort2, short paramShort3, byte[] paramArrayOfByte)
  {
    this.jdField_c_of_type_Byte = paramByte;
    this.jdField_d_of_type_Short = paramShort3;
    this.jdField_b_of_type_Short = paramShort1;
    this.jdField_c_of_type_Short = paramShort2;
    this.jdField_a_of_type_ArrayOfByte = paramArrayOfByte;
    this.jdField_a_of_type_JavaUtilVector = new Vector();
    this.jdField_a_of_type_Array2dOfByte = new byte[][] { { -1, -1, -1 }, { -1, -1, -1 }, { -1, -1, -1 } };
    this.jdField_b_of_type_ArrayOfByte = new byte[j.jdField_a_of_type_Array2dOfByte.length];
    this.jdField_a_of_type_ArrayOfShort = new short[] { 0, 0, 0, 0, 0, 0 };
    this.jdField_d_of_type_Byte = -1;
    this.f = -1;
    this.g = -1;
  }
}


/* Location:              C:\WPrograming\jd-gui-windows-1.4.0\Download_For_Motorola_128x160.jar!\h.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */