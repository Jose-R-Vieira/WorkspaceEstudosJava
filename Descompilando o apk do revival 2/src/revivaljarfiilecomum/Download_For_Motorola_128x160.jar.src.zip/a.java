import java.util.Vector;

public final class a
{
  public final byte a;
  public short a;
  public short b;
  public short c;
  public final byte b;
  public byte c;
  public short d;
  public byte d;
  public byte e;
  public short e = -1;
  public short f;
  public short g;
  public byte f;
  public byte g;
  public byte h;
  public short h;
  public Vector a;
  
  public a(byte paramByte1, short paramShort1, short paramShort2, byte paramByte2, byte paramByte3, short paramShort3)
  {
    this.jdField_f_of_type_Short = -1;
    this.jdField_a_of_type_Byte = paramByte1;
    this.jdField_b_of_type_Short = paramShort1;
    this.jdField_c_of_type_Short = paramShort2;
    this.jdField_b_of_type_Byte = paramByte2;
    this.jdField_c_of_type_Byte = paramByte3;
    this.d = paramShort3;
    this.g = 1;
    this.jdField_f_of_type_Byte = 9;
    this.h = 0;
    if (l.b[paramByte2][10] == 4) {
      this.jdField_a_of_type_JavaUtilVector = new Vector();
    }
  }
}


/* Location:              C:\WPrograming\jd-gui-windows-1.4.0\Download_For_Motorola_128x160.jar!\a.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */