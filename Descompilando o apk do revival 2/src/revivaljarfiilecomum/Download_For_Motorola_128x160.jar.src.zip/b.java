public final class b
{
  public final short a;
  public final Object[] a;
  public final int[] a;
  
  public b(short paramShort, Object[] paramArrayOfObject, int[] paramArrayOfInt)
  {
    this.jdField_a_of_type_Short = paramShort;
    this.jdField_a_of_type_ArrayOfInt = paramArrayOfInt;
    this.jdField_a_of_type_ArrayOfJavaLangObject = paramArrayOfObject;
  }
}


/* Location:              C:\WPrograming\jd-gui-windows-1.4.0\Download_For_Motorola_128x160.jar!\b.class
 * Java compiler version: 1 (45.3)
 * JD-Core Version:       0.7.1
 */